/*
The HtDP book includes the data definition for Ancestor Trees:
 ;; An Ancestor Tree (AT) is one of
 ;; -- 'unknown
 ;; -- (make-tree Person AT AT)
 ;; A Person is defined as above

Convert this data definition into Java classes and interfaces. What options do you have for
how to translate this into Java? Make examples of ancestor trees that in at least one branch cover at least three generations.
*/

interface IAncestorTree {

}

class Unknown implements IAncestorTree {

  Unknown() {
  }
}

class PersonAT implements IAncestorTree {

  String name;
  IAncestorTree atLeft;
  IAncestorTree atRight;

  PersonAT(String name, IAncestorTree atLeft, IAncestorTree atRight) {
    this.name = name;
    this.atLeft = atLeft;
    this.atRight = atRight;
  }
}

class ExamplesAT {

  ExamplesAT() {
  }

  // unknown at
  IAncestorTree unknown = new Unknown();
  // at with no childs
  IAncestorTree at1 = new PersonAT("Tim", this.unknown, this.unknown);
  IAncestorTree at2 = new PersonAT("Elisa", this.unknown, this.unknown);
  // at with length 1
  IAncestorTree at3 = new PersonAT
      ("Rebecca", this.at1, this.at2);
  IAncestorTree at4 = new PersonAT
      ("Eduard", this.at1, this.at2);
  // at with length 2 => 3 generations
  IAncestorTree at5 = new PersonAT
      ("Kate", this.at3, this.at4);
}
