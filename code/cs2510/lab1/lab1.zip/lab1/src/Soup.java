import java.util.ArrayList;
import java.util.List;

interface IMenuItem {

}

// represent an item soup of the menu
class Soup implements IMenuItem {

  String name;
  int price;
  boolean isVegeterian;

  Soup(String name, int price, boolean isVegeterian) {
    this.name = name;
    this.price = price;
    this.isVegeterian = isVegeterian;
  }
}

// represent an item salad of the menu
class Salad implements IMenuItem {

  String name;
  int price;
  boolean isVegeterian;
  String[] sauces;

  Salad(String name, int price, boolean isVegeterian, String[] sauces) {
    this.name = name;
    this.price = price;
    this.isVegeterian = isVegeterian;
    this.sauces = sauces;
  }
}

// represent an item sandwich of the menu
class Sandwich implements IMenuItem {

  String name;
  int price;
  String kob;
  String firstFilling;
  String secondFilling;

  Sandwich(String name, int price, String kob, String firstFilling, String secondFilling) {
    this.name = name;
    this.price = price;
    this.kob = kob;
    this.firstFilling = firstFilling;
    this.secondFilling = secondFilling;
  }
}

class ExamplesMenu {

  ExamplesMenu() {
  }

  IMenuItem so1 = new Soup("Soup 1", 10, false);
  IMenuItem so2 = new Soup("Soup 2", 5, true);
  String[] sauces1 = new String[0];
  IMenuItem sal1 = new Salad("Salad 1", 3, true, this.sauces1);
  IMenuItem sal2 = new Salad("Salad 2", 5, false, this.sauces1);
  IMenuItem san1 = new Sandwich("Sandwich 1", 20, "Normal", "Peanut Butter", "Jelly");
  IMenuItem san2 = new Sandwich("Sandwich 2", 10, "Large", "Ham", "Cheese");
}
