import tester.Tester;

// Represents a mode of transportation
interface IMOT {

  // returns true if this mode of transportation is at least
  // as efficient as the given mpg, false otherwise
  boolean isMoreFuelEfficientThan(int mpg);
}

// Represents a bicycle as a mode of transportation
class Bicycle implements IMOT {

  String brand;

  Bicycle(String brand) {
    this.brand = brand;
  }

  /*
   * TEMPLATE
   * +------------------------------------------+
   * FIELDS
   * ... this.brand ... -- String
   * +------------------------------------------+
   * METHODS
   * ... this.isMoreFuelEfficientThan(int mpg) ... -- boolean
   * +------------------------------------------+
   */

  // a bicycle does not consume fuel, so it will always be more fuel efficient
  @Override
  public boolean isMoreFuelEfficientThan(int mpg) {
    return true;
  }
}

// Represents a car as a mode of transportation
class Car implements IMOT {

  String make;
  int mpg; // represents the fuel efficiency in miles per gallon

  Car(String make, int mpg) {
    this.make = make;
    this.mpg = mpg;
  }

  /*
   * TEMPLATE
   * +------------------------------------------+
   * FIELDS
   * ... this.make ... -- String
   * ... this.mpg ... --  int
   * +------------------------------------------+
   * METHODS
   * ... this.isMoreFuelEfficientThan(int mpg) ... -- boolean
   * +------------------------------------------+
   */

  // compare this car's fuel efficiency to the given fuel efficiency
  @Override
  public boolean isMoreFuelEfficientThan(int mpg) {
    return this.mpg >= mpg;
  }
}

// Keeps track of how a person is transported
class Person {

  String name;
  IMOT mot;

  Person(String name, IMOT mot) {
    this.name = name;
    this.mot = mot;
  }

  /*
   * TEMPLATE
   * +------------------------------------------+
   * FIELDS
   * ... this.name ... -- String
   * ... this.mot ... --  MOT
   * +------------------------------------------+
   * METHODS
   * ... this.motMeetsFuelEfficiency(int mpg) ... -- boolean
   * +------------------------------------------+
   * METHODS OF FIELDS:
   * ... this.mot.isMoreFuelEfficientThan(int mpg) ... -- boolean
   * +------------------------------------------+
   */

  // Does this person's mode of transportation meet the given fuel
  // efficiency target (in miles per gallon)?
  boolean motMeetsFuelEfficiency(int mpg) {
    return this.mot.isMoreFuelEfficientThan(mpg);
  }

  /*
  // Does this person's mode of transportation meet the given mpg of the arg
  boolean motIsMoreFuelEfficientThan(IMOT mot){
    return !mot.isMoreFuelEfficientThan(this.mot.getMpg());
  }
   */

}

class ExamplesPerson {

  IMOT diamondback = new Bicycle("Diamondback");
  IMOT toyota = new Car("Toyota", 30);
  IMOT lamborghini = new Car("Lamborghini", 17);

  Person bob = new Person("Bob", diamondback);
  Person ben = new Person("Ben", toyota);
  Person becca = new Person("Becca", lamborghini);

  //  to test method motMeeetsFuelEfficiency of Person type
  boolean testPersonMotMeetsFuelEfficiency(Tester t) {
    return
        t.checkExpect(this.bob.motMeetsFuelEfficiency(15), true) &&
            t.checkExpect(this.ben.motMeetsFuelEfficiency(15), true) &&
            t.checkExpect(this.becca.motMeetsFuelEfficiency(15), true) &&
            t.checkExpect(this.bob.motMeetsFuelEfficiency(25), true) &&
            t.checkExpect(this.ben.motMeetsFuelEfficiency(25), true) &&
            t.checkExpect(this.becca.motMeetsFuelEfficiency(25), false);
  }

}