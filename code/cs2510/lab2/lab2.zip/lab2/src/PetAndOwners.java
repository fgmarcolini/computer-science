import tester.Tester;

// to represent a pet owner
class PetOwner {

  String name;
  IPet pet;
  int age;

  PetOwner(String name, IPet pet, int age) {
    this.name = name;
    this.pet = pet;
    this.age = age;
  }

  /*
   * TEMPLATE
   * +------------------------------------------+
   * FIELDS
   * ... this.name ... -- String
   * ... this.pet ... -- IPet
   * ... this.age ... -- int
   * +------------------------------------------+
   * METHODS
   * ... this.isOlder(PetOwner other) ... -- boolean
   * ... this.sameNamePet(String pet) ... -- boolean
   * ... this.perish ... -- PetOwner
   * +------------------------------------------+
   * METHODS OF FIELDS
   * ... this.pet.sameName(String pet) ... -- boolean
   * +------------------------------------------+
   */

  // is this PetOwner older than the given PetOwner?
  boolean isOlder(PetOwner other) {
    return this.age > other.age;
  }

  // does the name of this person's pet match the given name?
  boolean sameNamePet(String pet) {
    return this.pet.sameName(pet);
  }

  // produces a PetOwner whose pet has perished.
  PetOwner perish() {
    return new PetOwner(this.name, new NoPet(), this.age);
  }
}

// to represent a pet
interface IPet {

  // does the name of this pet match the given name?
  boolean sameName(String pet);
}

// to represent a pet cat
class Cat implements IPet {

  String name;
  String kind;
  boolean longHaired;

  Cat(String name, String kind, boolean longHaired) {
    this.name = name;
    this.kind = kind;
    this.longHaired = longHaired;
  }

  /*
   * TEMPLATE
   * +------------------------------------------+
   * FIELDS
   * ... this.name ... -- String
   * ... this.kind ... -- String
   * ... this.longHaired ... -- boolean
   * +------------------------------------------+
   * METHODS
   * ... this.sameName(String pet) ... -- boolean
   * +------------------------------------------+
   */

  // does the name of this Cat match the given name?
  @Override
  public boolean sameName(String pet) {
    return this.name.equals(pet);
  }
}

// to represent a pet dog
class Dog implements IPet {

  String name;
  String kind;
  boolean male;

  Dog(String name, String kind, boolean male) {
    this.name = name;
    this.kind = kind;
    this.male = male;
  }

  /*
   * TEMPLATE
   * +------------------------------------------+
   * FIELDS
   * ... this.name ... -- String
   * ... this.kind ... -- String
   * ... this.male ... -- boolean
   * +------------------------------------------+
   * METHODS
   * ... this.sameName(String pet) ... -- boolean
   * +------------------------------------------+
   */

  // does the name of this Dog match the given name?
  @Override
  public boolean sameName(String pet) {
    return this.name.equals(pet);
  }
}

// to represent the abscence of a pet
class NoPet implements IPet {

  // There's no name for a pet that doesn't exist.
  @Override
  public boolean sameName(String pet) {
    return false;
  }
}

class ExamplesPetOwners {

  IPet cat1 = new Cat("Kitty", "Siamese", false);
  IPet cat2 = new Cat("Destroyer", "Persian", true);
  IPet dog1 = new Dog("Princess", "Pitbull", false);
  IPet dog2 = new Dog("Behemoth", "Chihuahua", true);
  PetOwner bill = new PetOwner("Bill", this.cat1, 18);
  PetOwner silvia = new PetOwner("Silvia", this.cat2, 22);
  PetOwner karen = new PetOwner("Karen", this.dog1, 40);
  PetOwner adam = new PetOwner("Adam", this.dog2, 35);
  PetOwner rick = new PetOwner("Rick", new NoPet(), 20);
  PetOwner peter = new PetOwner("Peter", new NoPet(), 28);

  boolean testPetOwnerIsOlder(Tester t) {
    return
        t.checkExpect(this.bill.isOlder(this.bill), false) &&
            t.checkExpect(this.bill.isOlder(this.silvia), false) &&
            t.checkExpect(this.karen.isOlder(this.adam), true) &&
            t.checkExpect(this.adam.isOlder(this.bill), true);
  }

  boolean testPetOwnerSameNamePet(Tester t) {
    return
        t.checkExpect(this.bill.sameNamePet("Kitty"), true) &&
            t.checkExpect(this.bill.sameNamePet("Destroyer"), false) &&
            t.checkExpect(this.karen.sameNamePet("Princess"), true) &&
            t.checkExpect(this.adam.sameNamePet("Princess"), false) &&
            t.checkExpect(this.rick.sameNamePet("Kitty"), false);
  }

  boolean testPetOwnerPerish(Tester t) {
    return
        t.checkExpect(this.bill.perish(), new PetOwner("Bill", new NoPet(), 18)) &&
            t.checkExpect(this.karen.perish(), new PetOwner("Karen", new NoPet(), 40)) &&
            t.checkExpect(this.peter.perish(), this.peter);
  }

}