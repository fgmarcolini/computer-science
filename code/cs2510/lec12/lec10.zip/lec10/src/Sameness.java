import tester.Tester;

interface IShape {

  boolean sameShape(IShape that);

  boolean sameCircle(Circle otherCircle);

  boolean sameRect(Rect otheRect);

  boolean sameSquare(Square otherSquare);
}

class Circle implements IShape {

  int x, y;
  int radius;

  Circle(int x, int y, int radius) {
    this.x = x;
    this.y = y;
    this.radius = radius;
  }

  @Override
  public boolean sameShape(IShape that) {
    return that.sameCircle(this); // first dispatch
  }

  public boolean sameCircle(Circle that) {
    /* Template:
     * Fields:
     * this.x, this.y, this.radius
     *
     * Fields of parameters:
     * that.x, that.y, that.radius
     */
    return this.x == that.x &&
        this.y == that.y &&
        this.radius == that.radius;
  } // second dispatch

  @Override
  public boolean sameRect(Rect otheRect) {
    return false;
  } // second dispatch

  @Override
  public boolean sameSquare(Square otherSquare) {
    return false;
  }
}

class Rect implements IShape {

  int x, y;
  int w, h;

  Rect(int x, int y, int w, int h) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
  }

  @Override
  public boolean sameShape(IShape that) {
    return that.sameRect(this); // first dispatch
  }

  @Override
  public boolean sameCircle(Circle otherCircle) {
    return false; // second dispatch
  }

  public boolean sameRect(Rect that) {
    /* Template:
     * Fields:
     * this.x, this.y, this.w, this.h
     *
     * Fields of parameters:
     * that.x, that.y, that.w, that.h
     */
    return this.x == that.x &&
        this.y == that.y &&
        this.w == that.w &&
        this.h == that.h;
  } // second dispatch

  @Override
  public boolean sameSquare(Square otherSquare) {
    return false;
  }
}

class Square extends Rect {

  Square(int x, int y, int s) {
    super(x, y, s, s);
  }

  public boolean sameShape(IShape that) {
    return that.sameSquare(this);
  }

  public boolean sameSquare(Square that) {
    return this.x == that.x &&
        this.y == that.y &&
        this.w == that.w; // No need to check the h field, too...
  }
}

class ExamplesSameness {

  IShape c1 = new Circle(3, 4, 5);
  IShape c2 = new Circle(4, 5, 6);
  IShape c3 = new Circle(3, 4, 5);
  IShape r1 = new Rect(3, 4, 5, 5);
  IShape r2 = new Rect(4, 5, 6, 7);
  IShape r3 = new Rect(3, 4, 5, 5);
  IShape s1 = new Square(3, 4, 5);
  IShape s2 = new Square(4, 5, 6);
  IShape s3 = new Square(3, 4, 5);

  boolean testSameCircle(Tester t) {
    return
        t.checkExpect(c1.sameCircle((Circle) c2), false) &&
            t.checkExpect(c2.sameCircle((Circle) c1), false) &&
            t.checkExpect(c1.sameCircle((Circle) c3), true) &&
            t.checkExpect(c3.sameCircle((Circle) c1), true);
  }

  boolean testSameRect(Tester t) {
    return
        t.checkExpect(r1.sameRect((Rect) r2), false) &&
            t.checkExpect(r2.sameRect((Rect) r1), false) &&
            t.checkExpect(r1.sameRect((Rect) r3), true) &&
            t.checkExpect(r3.sameRect((Rect) r1), true);
  }

  boolean testSameShape(Tester t) {
    return
        t.checkExpect(c1.sameShape(c3), true) && // works
            t.checkExpect(c1.sameShape(c2), false) &&// works
            t.checkExpect(r1.sameShape(r3), true) &&// works
            t.checkExpect(r1.sameShape(r2), false) &&// works
            t.checkExpect(c1.sameShape(r1), false) && // CRASH! with a ClassCastException
            t.checkExpect(r1.sameShape(c1), false) && // works
            t.checkExpect(s1.sameShape(s2), false) &&
            t.checkExpect(s2.sameShape(s1), false) &&
            t.checkExpect(s1.sameShape(s3), true) &&
            t.checkExpect(s3.sameShape(s1), true) &&
            // Comparing a Square with a Rect of a different size
            t.checkExpect(s1.sameShape(r2), false) && // Good
            t.checkExpect(r2.sameShape(s1), false) && // Good
            // Comparing a Square with a Rect of the same size
            t.checkExpect(s1.sameShape(r1), false) && // Good
            t.checkExpect(r1.sameShape(s1), true);  // Not so good

  }
}