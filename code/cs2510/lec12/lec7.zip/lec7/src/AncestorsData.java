import tester.*;

/**
 * HtDC Lectures Lecture 7: Accumulator methods, continued
 * <p>
 * Copyright 2013 Viera K. Proulx This program is distributed under the terms of the GNU Lesser
 * General Public License (LGPL)
 *
 * @since 29 August 2013
 */

// to represent an ancestor tree
interface IAT {

  // To compute the number of known ancestors of this ancestor tree
  // (excluding this ancestor tree itself)
  int count();

  // To compute the number of known ancestors of this ancestor tree
  // (*including* this ancestor tree itself)
  int countHelper();

  // To compute how many ancestors of this ancestor tree (excluding this
  // ancestor tree itself) are women older than 40 (in the current year)?
  int femaleAncOver40();

  // To compute how many ancestors of this ancestor tree (*including* this
  // ancestor tree itself) are women older than 40 (in the current year)?
  int femaleAncOver40Helper();

  // To compute whether this ancestor tree is well-formed: are all known
  // people younger than their parents?
  boolean wellFormed();

  boolean wellFormedHelper(int yob);

  // To compute how many generations (including this IAT's generation) are
  // COMPLETELY known.
  int numTotalGens();

  // To compute how many generations (including this IAT's generation) are
  // at least PARTIALLY known.
  int numPartialGens();

  // To compute the names of all the known ancestors in this ancestor tree
  // (*including* this ancestor tree itself)
  ILoString ancNames();

  // is this IAT an instance of Unknown class?
  boolean isUnknown();

  // To return the younger of this IAT and the given ancestor tree
  IAT youngerIAT(IAT other);

  // To return either this ancestor tree (if this ancestor tree is younger
  // than the given yob) or the given ancestry tree
  IAT youngerIATHelper(IAT other, int otherYob);

  // To compute the youngest parent of this ancestry tree
  IAT youngestParent();

  // To compute the youngest grandparent of this ancestry tree
  IAT youngestGrandparent();

  // To compute the youngest ancestor in the given generation of this ancestry tree.
  IAT youngestAncAtGen(int gen);

  // if this ancestor's tree equals the given ancestor's tree
  boolean sameIAT(IAT other);

  boolean sameUnknown(Unknown other);

  boolean samePerson(Person other);
}

// to represent an unknown member of an ancestor tree
class Unknown implements IAT {

  Unknown() {
  }

  // To compute the number of known ancestors of this ancestor tree (excluding this Unknown itself)
  @Override
  public int count() {
    return 0;
  }

  // To compute the number of known ancestors of this ancestor tree (*including* this Unknown itself)
  @Override
  public int countHelper() {
    return 0;
  }


  // To compute how many ancestors of this ancestor tree (excluding this
  // ancestor tree itself) are women older than 40 (in the current year)?
  @Override
  public int femaleAncOver40() {
    return 0;
  }

  // To compute how many ancestors of this ancestor tree (*including* this
  // ancestor tree itself) are women older than 40 (in the current year)?
  @Override
  public int femaleAncOver40Helper() {
    return 0;
  }

  // To compute whether this ancestor tree is well-formed: are all known
  // people younger than their parents?
  @Override
  public boolean wellFormed() {
    return true;
  }

  @Override
  public boolean wellFormedHelper(int yob) {
    return true;
  }

  // To compute how many generations (excluding this Unknown's generation) are
  // COMPLETELY known.
  @Override
  public int numTotalGens() {
    return 0;
  }

  // To compute how many generations (excluding this Unknown's generation) are
  // at least PARTIALLY known.
  @Override
  public int numPartialGens() {
    return 0;
  }

  // To compute the names of all the known ancestors in this ancestor tree
  // (excluding this Unknown itself)
  @Override
  public ILoString ancNames() {
    return new MtLoString();
  }

  // is this IAT an instance of Unknown class? (*true* for this Unknown)
  @Override
  public boolean isUnknown() {
    return true;
  }

  // To return the younger of this Unknown and the given ancestor tree
  @Override
  public IAT youngerIAT(IAT other) {
    return other;
  }

  // To return either this Unknown (if this Unknown is younger
  // than the given yob) or the given ancestry tree
  @Override
  public IAT youngerIATHelper(IAT other, int otherYob) {
    return other;
  }

  // To compute the youngest parent of this Unknown
  @Override
  public IAT youngestParent() {
    return new Unknown();
  }

  // To compute the youngest grandparent of this Unknown
  @Override
  public IAT youngestGrandparent() {
    return new Unknown();
  }

  // To compute the youngest ancestor in the given generation of this Unknown.
  @Override
  public IAT youngestAncAtGen(int gen) {
    return (gen == 0) ? this : new Unknown();
  }

  // if this Unknown equals to the given ancestor's tree
  @Override
  public boolean sameIAT(IAT other) {
    return other.sameUnknown(this); // first dispatch
  }

  @Override
  public boolean sameUnknown(Unknown other) {
    return true;  // second dispatch
  }

  @Override
  public boolean samePerson(Person other) {
    return false;   // second dispatch
  }
}

// to represent a person with the person's ancestor tree
class Person implements IAT {

  String name;
  int yob;
  boolean isMale;
  IAT mom;
  IAT dad;

  Person(String name, int yob, boolean isMale, IAT mom, IAT dad) {
    this.name = name;
    this.yob = yob;
    this.isMale = isMale;
    this.mom = mom;
    this.dad = dad;
  }

  /* Template:
   * Fields:
   * this.name -- String
   * this.yob -- int
   * this.isMale -- boolean
   * this.mom -- IAT
   * this.dad -- IAT
   * Methods:
   * this.count() -- int
   * this.countHelper() -- int
   * this.femaleAncOver40() -- int
   * this.femaleAncOver40Helper() -- int
   * this.wellFormed() -- boolean
   * this.wellFormedHelper(int childYob) -- boolean
   * this.numTotalGens() -- int
   * this.numPartialGens() -- int
   * this.ancNames() -- ILoString
   * this.isUnknown() -- boolean
   * this.youngerIAT(IAT other) -- IAT
   * this.youngerIATHelper(IAT other, int otherYob) -- IAT
   * this.youngestParent() -- IAT
   * this.youngestGrandparent() -- IAT
   * this.youngestAncAtGen(int gen) -- IAT
   * Methods of fields:
   * this.mom. ... . (all of IAT type)
   * this.dad. ... . (all of IAT type)
   */

  // Is this Person younger than the other Person
  boolean youngerThan(Person other) {
    return this.yob < other.yob;
  }

  // To compute the number of known ancestors of this ancestor tree (excluding this Person itself)
  @Override
  public int count() {
    return this.mom.countHelper() + this.dad.countHelper();
  }

  // To compute the number of known ancestors of this ancestor tree (*including* this Person itself)
  @Override
  public int countHelper() {
    return 1 + this.mom.countHelper() + this.dad.countHelper();
  }

  // To compute how many ancestors of this ancestor tree (excluding this
  // ancestor tree itself) are women older than 40 (in the current year)?
  @Override
  public int femaleAncOver40() {
    return this.mom.femaleAncOver40Helper() + this.dad.femaleAncOver40Helper();
  }

  // To compute how many ancestors of this ancestor tree (*including* this
  // ancestor tree itself) are women older than 40 (in the current year)?
  @Override
  public int femaleAncOver40Helper() {
    if (2015 - this.yob > 40 && !this.isMale) {
      return 1 + this.mom.femaleAncOver40Helper() + this.dad.femaleAncOver40Helper();
    } else {
      return this.mom.femaleAncOver40Helper() + this.dad.femaleAncOver40Helper();
    }
  }

  // To compute whether this ancestor tree is well-formed: are all known
  // people younger than their parents?
  @Override
  public boolean wellFormed() {
    return this.mom.wellFormedHelper(this.yob) && this.dad.wellFormedHelper(this.yob);
  }

  @Override
  public boolean wellFormedHelper(int childYob) {
    return (childYob > this.yob) && this.mom.wellFormedHelper(this.yob)
        && this.dad.wellFormedHelper(
        this.yob);
  }

  // To compute how many generations (*including* this Person's generation) are
  // COMPLETELY known.
  @Override
  public int numTotalGens() {
    if (!this.mom.isUnknown() && !this.dad.isUnknown()) {
      return 1 + Math.min(this.mom.numTotalGens(), this.dad.numTotalGens());
    } else {
      return 1;
    }
  }

  // To compute how many generations (*including* this Person's generation) are
  // at least PARTIALLY known.
  @Override
  public int numPartialGens() {
    return 1 + Math.max(this.mom.numPartialGens(), this.dad.numPartialGens());
  }

  // To compute the names of all the known ancestors in this ancestor tree
  // (*including* this Person itself)
  @Override
  public ILoString ancNames() {
    ConsLoString momAncNames = new ConsLoString(this.name, this.mom.ancNames());
    return momAncNames.append(this.dad.ancNames());
  }

  // is this IAT an instance of Unknown class? (*false* for this Person)
  @Override
  public boolean isUnknown() {
    return false;
  }

  // To return the younger of this Person and the given ancestor tree
  @Override
  public IAT youngerIAT(IAT other) {
    return other.youngerIATHelper(this, this.yob); // dynamic dispatch
  }

  // To return either this Person (if this Person is younger
  // than the given yob) or the given ancestry tree
  @Override
  public IAT youngerIATHelper(IAT other, int otherYob) {
    return (this.yob > otherYob) ? this : other;
  }

  // To compute the youngest parent of this Person
  @Override
  public IAT youngestParent() {
    //return this.mom.youngerIAT(this.dad);
    return this.youngestAncAtGen(1);
  }

  // To compute the youngest grandparent of this Person
  @Override
  public IAT youngestGrandparent() {
    //return this.mom.youngestParent().youngerIAT(this.dad.youngestParent());
    return this.youngestAncAtGen(2);
  }

  // To compute the youngest ancestor in the given generation of this Person.
  @Override
  public IAT youngestAncAtGen(int gen) {
    return (gen == 0) ? this :
        this.mom.youngestAncAtGen(gen - 1).youngerIAT(this.dad.youngestAncAtGen(gen - 1));
  }

  // if this Person equals to the given ancestor's tree
  @Override
  public boolean sameIAT(IAT other) {
    return other.samePerson(this);  // first dispatch
  }

  @Override
  public boolean sameUnknown(Unknown other) {
    return false; // second dispatch
  }

  @Override
  public boolean samePerson(Person other) {
    return  // second dispatch
        this.name.equals(other.name) &&
            this.yob == other.yob &&
            this.isMale == other.isMale &&
            this.mom.sameIAT(other.mom) &&
            this.dad.sameIAT(other.dad);
  }
}

// To represent a list of strings
interface ILoString {

  // To compute the append of this first ILoString and the other ILoString
  ILoString append(ILoString other);
}

// To represent a list of strings non-empty.
class ConsLoString implements ILoString {

  String first;
  ILoString rest;

  ConsLoString(String first, ILoString rest) {
    this.first = first;
    this.rest = rest;
  }

  // To compute the append of this first ConsLoString and the other ILoString
  public ILoString append(ILoString other) {
    return new ConsLoString(this.first, this.rest.append(other));
  }
}

// To represent a list of strings empty.
class MtLoString implements ILoString {

  MtLoString() {
  }

  // To compute the append of this first MtLoString and the other ILoString
  @Override
  public ILoString append(ILoString other) {
    return other;
  }
}

// examples and tests for the class hierarchy that represents
// ancestor trees
class ExamplesAncestors {

  ExamplesAncestors() {
  }

  IAT enid = new Person("Enid", 1904, false, new Unknown(), new Unknown());
  IAT edward = new Person("Edward", 1902, true, new Unknown(), new Unknown());
  IAT emma = new Person("Emma", 1906, false, new Unknown(), new Unknown());
  IAT eustace = new Person("Eustace", 1907, true, new Unknown(), new Unknown());

  IAT david = new Person("David", 1925, true, new Unknown(), this.edward);
  IAT daisy = new Person("Daisy", 1927, false, new Unknown(), new Unknown());
  IAT dana = new Person("Dana", 1933, false, new Unknown(), new Unknown());
  IAT darcy = new Person("Darcy", 1930, false, this.emma, this.eustace);
  IAT darren = new Person("Darren", 1935, true, this.enid, new Unknown());
  IAT dixon = new Person("Dixon", 1936, true, new Unknown(), new Unknown());

  IAT clyde = new Person("Clyde", 1955, true, this.daisy, this.david);
  IAT candace = new Person("Candace", 1960, false, this.dana, this.darren);
  IAT cameron = new Person("Cameron", 1959, true, new Unknown(), this.dixon);
  IAT claire = new Person("Claire", 1956, false, this.darcy, new Unknown());

  IAT bill = new Person("Bill", 1980, true, this.candace, this.clyde);
  IAT bree = new Person("Bree", 1981, false, this.claire, this.cameron);

  IAT andrew = new Person("Andrew", 2001, true, this.bree, this.bill);

  boolean testCount(Tester t) {
    return
        t.checkExpect(this.andrew.count(), 16) &&
            t.checkExpect(this.david.count(), 1) &&
            t.checkExpect(this.enid.count(), 0) &&
            t.checkExpect(new Unknown().count(), 0);
  }

  boolean testFemaleAncOver40(Tester t) {
    return
        t.checkExpect(this.andrew.femaleAncOver40(), 7) &&
            t.checkExpect(this.bree.femaleAncOver40(), 3) &&
            t.checkExpect(this.darcy.femaleAncOver40(), 1) &&
            t.checkExpect(this.enid.femaleAncOver40(), 0) &&
            t.checkExpect(new Unknown().femaleAncOver40(), 0);
  }

  boolean testWellFormed(Tester t) {
    return
        t.checkExpect(this.andrew.wellFormed(), true) &&
            t.checkExpect(new Unknown().wellFormed(), true) &&
            t.checkExpect(
                new Person("Zane", 2000, true, this.andrew, this.bree).wellFormed(),
                false);
  }

  boolean testNumGens(Tester t) {
    return
        t.checkExpect(this.andrew.numTotalGens(), 3) &&
            t.checkExpect(this.andrew.numPartialGens(), 5) &&
            t.checkExpect(this.enid.numTotalGens(), 1) &&
            t.checkExpect(this.enid.numPartialGens(), 1) &&
            t.checkExpect(new Unknown().numTotalGens(), 0) &&
            t.checkExpect(new Unknown().numPartialGens(), 0);
  }

  boolean testAncNames(Tester t) {
    return
        t.checkExpect(this.david.ancNames(),
            new ConsLoString("David",
                new ConsLoString("Edward", new MtLoString()))) &&
            t.checkExpect(this.eustace.ancNames(),
                new ConsLoString("Eustace", new MtLoString())) &&
            t.checkExpect(new Unknown().ancNames(), new MtLoString());
  }

  boolean testIATYoungerIAT(Tester t) {
    return
        t.checkExpect(this.bree.youngerIAT(this.bill), this.bree) &&
            t.checkExpect(this.candace.youngerIAT(this.cameron), this.candace);
  }

  boolean testIATYoungestParent(Tester t) {
    return
        t.checkExpect(this.andrew.youngestParent(), this.bree) &&
            t.checkExpect(this.bree.youngestParent(), this.cameron);
  }

  boolean testIATYoungestGrandparent(Tester t) {
    return
        t.checkExpect(this.andrew.youngestGrandparent(), this.candace) &&
            t.checkExpect(this.bree.youngestGrandparent(), this.dixon);
  }

  boolean testIATYoungestAncAtGen(Tester t) {
    return
        t.checkExpect(this.andrew.youngestAncAtGen(0), this.andrew) &&
            t.checkExpect(this.andrew.youngestAncAtGen(1), this.bree) &&
            t.checkExpect(this.andrew.youngestAncAtGen(2), this.candace) &&
            t.checkExpect(this.andrew.youngestAncAtGen(3), this.dixon) &&
            t.checkExpect(this.andrew.youngestAncAtGen(4), this.eustace);
  }

  boolean testAppendString(Tester t) {
    return
        t.checkExpect(this.david.ancNames().append(this.david.ancNames()),
            new ConsLoString("David",
                new ConsLoString("Edward",
                    new ConsLoString("David",
                        new ConsLoString("Edward", new MtLoString())))));
  }

  boolean testSameIAT(Tester t) {
    return
        t.checkExpect(this.david.sameIAT(this.david), true) &&
            t.checkExpect(this.david.sameIAT(new Unknown()), false) &&
            t.checkExpect(this.david.sameIAT(this.andrew), false);
  }

}