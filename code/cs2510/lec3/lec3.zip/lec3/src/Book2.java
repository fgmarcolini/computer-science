import tester.Tester;

// to represent a book in a bookstore
class Book2 {

  String title;
  Author2 author;
  int price;

  // the constructor
  Book2(String title, Author2 author, int price) {
    this.title = title;
    this.author = author;
    this.price = price;
  }

  /*
    TEMPLATE:
    Fields:
    ... this.title ... -- String
    ... this.author.getName() ... -- String
    ... this.author.getYOB() ... -- int
    ... this.price ... -- int

    Methods:
    ... this.salePrice(int) ... -- int
    ... this.sameAuthor(Book2) ... -- boolean
    ... this.reducePrice(Book2) ... -- Book2

    Methods for fields:
    ... this.author.sameAuthor(Author2) ... -- boolean
   */

  // Compute the sale price of this Book given using
  // the given discount rate (as a percentage)
  int salePrice(int discount) {
    return this.price - (this.price * discount) / 100;
  }

  // is this book written by the same author as the given book?
  boolean sameAuthor(Book2 other) {
    return this.author.sameAuthor(other.author);
  }

  // produce a book like this one, but with the price reduced by 20%
  Book2 reducePrice() {
    return new Book2(this.title, this.author, this.salePrice(20));
  }

}

// to represent a author of a book in a bookstore
class Author2 {

  String name;
  int yob;

  // the constructor
  Author2(String name, int yob) {
    this.name = name;
    this.yob = yob;
  }

  /*
    TEMPLATE:
    Fields:
    ... this.name ...   -- String
    ... this.yob ...    -- int

    Methods:
    ... this.sameAuthor(Autor) ...  -- boolean
   */

  // is this the same author as the given one?
  boolean sameAuthor(Author2 that) {
    return this.name.equals(that.name)
        && (this.yob == that.yob);
  }
}


// examples and tests for the classes that represent books and authors
class ExamplesBooksAuthors2 {

  ExamplesBooksAuthors2() {
  }

  // examples of authors
  Author2 pat = new Author2("Pat Conroy", 1948);
  Author2 dan = new Author2("Dan Brown", 1962);

  // examples of books
  Book2 htdp = new Book2("HtDP", this.dan, 60);
  Book2 beaches = new Book2("Beaches", this.pat, 20);
  Book2 prince = new Book2("Prince of Tides", this.pat, 15);
  Book2 code = new Book2("Da Vinci Code", this.dan, 20);

  // test the method sameAuthor in the class Author2
  boolean testSameAuthor(Tester t) {
    return t.checkExpect(this.dan.sameAuthor(this.dan), true)
        && t.checkExpect(this.dan.sameAuthor(this.pat), false)
        && t.checkExpect(this.dan.sameAuthor(new Author2("Dan Brown", 1962)), true);
  }

  // test the method sameAuthor in the class Book2
  boolean testSameAuthorBook(Tester t) {
    return t.checkExpect(this.beaches.sameAuthor(this.prince), true)
        && t.checkExpect(this.beaches.sameAuthor(this.code), false);
  }

  // test the method salePrice in the class Book2
  boolean testSalePrice(Tester t) {
    return t.checkExpect(this.htdp.salePrice(30), 42)
        && t.checkExpect(this.beaches.salePrice(20), 16);
  }

  // test the method reducePrice for the class Book2
  boolean testReducePrice(Tester t) {
    return t.checkExpect(this.htdp.reducePrice(), new Book2("HtDP", this.dan, 48))
        && t.checkExpect(this.beaches.reducePrice(), new Book2("Beaches", this.pat, 16));
  }
}