import tester.Tester;

// to represent a book in a bookstore
class BookAuthor {

  String title;
  Author author;
  int price;

  // the constructor
  BookAuthor(String title, Author author, int price) {
    this.title = title;
    this.author = author;
    this.price = price;
  }

  /*
    TEMPLATE:
    Fields:
    ... this.title ... -- String
    ... this.author.getName() ... -- String
    ... this.author.getYOB() ... -- int
    ... this.price ... -- int

    Methods:
    ... this.salePrice(int) ... -- int
    ... this.sameAuthor(BookAuthor) ... -- boolean

    Methods for fields:
    ... this.author.sameAuthor(Author) ... -- boolean
   */

  // Compute the sale price of this Book given using
  // the given discount rate (as a percentage)
  int salePrice(int discount) {
    return this.price - (this.price * discount) / 100;
  }

  // is this book written by the same author as the given book?
  boolean sameAuthor(BookAuthor other) {
    return this.author.sameAuthor(other.author);
  }

}

// to represent a author of a book in a bookstore
class Author {

  String name;
  int yob;

  // the constructor
  Author(String name, int yob) {
    this.name = name;
    this.yob = yob;
  }

  /*
    TEMPLATE:
    Fields:
    ... this.name ...   -- String
    ... this.yob ...    -- int

    Methods:
    ... this.sameAuthor(Autor) ...  -- boolean
   */

  // is this the same author as the given one?
  boolean sameAuthor(Author that) {
    return this.name.equals(that.name)
        && (this.yob == that.yob);
  }
}


// examples and tests for the classes that represent books and authors
class ExamplesBooksAuthors {

  ExamplesBooksAuthors() {
  }

  // examples of authors
  Author pat = new Author("Pat Conroy", 1948);
  Author dan = new Author("Dan Brown", 1962);

  // examples of books
  BookAuthor htdp = new BookAuthor("HtDP", this.dan, 60);
  BookAuthor beaches = new BookAuthor("Beaches", this.pat, 20);
  BookAuthor prince = new BookAuthor("Prince of Tides", this.pat, 15);
  BookAuthor code = new BookAuthor("Da Vinci Code", this.dan, 20);

  // test the method sameAuthor in the class Author
  boolean testSameAuthor(Tester t) {
    return t.checkExpect(this.dan.sameAuthor(this.dan), true)
        && t.checkExpect(this.dan.sameAuthor(this.pat), false)
        && t.checkExpect(this.dan.sameAuthor(new Author("Dan Brown", 1962)), true);
  }

  // test the method sameAuthor in the class BookAuthor
  boolean testSameAuthorBook(Tester t) {
    return t.checkExpect(this.beaches.sameAuthor(this.prince), true)
        && t.checkExpect(this.beaches.sameAuthor(this.code), false);
  }

  // test the method salePrice in the class BookAuthor
  boolean testSalePrice(Tester t) {
    return t.checkExpect(this.htdp.salePrice(30), 42)
        && t.checkExpect(this.beaches.salePrice(20), 16);
  }
}