import tester.*;

class Book {

  String name;
  String author;
  double price;
  int year;

  Book(String name, String author, double price, int year) {
    this.name = name;
    this.author = author;
    this.price = price;
    this.year = year;
  }

  double getPrice() {
    return this.price;
  }

  // to return the discounted price of this book given the discount rate
  double discount(double rate) {
    return this.price - (rate * this.price);
  }

  // to return a new book with the same author and name as this book,
  // but with price discounted at the given rate
  Book discountedBook(double rate) {
    return new Book(this.name, this.author, this.discount(rate), this.year);
  }

  // to return the price of this book but with the discount given as arg.
  public double salePrice(double discount) {
    return this.price - discount;
  }

  // if this book is cheaper than arg book
  public boolean cheaperThan(Book first) {
    return this.price < first.price;
  }

  // if the title of this book is lexicographically before than arg book
  public boolean titleBefore(Book first) {
    return this.name.compareTo(first.name) < 0;
  }
}



/*
 * GOAL:
 * Represent a bunch of books, and be able to compute
 * - their total price
 * - how many books we have
 * - all the books published before the given year
 * - a sorted list of books
 */

/*
 * A list of books is one of
 * empty
 * (cons book list-of-books)
 */

// DYNAMIC DISPATCH: deciding which method definition to invoke (in which class)
// based on the information available at runtime of the object that's invoking
// the method

interface ILoBook {

  // to compute the total price of all books in this list of books
  double totalPrice();

  // to count how many books are in this list of books
  int count();

  // calculate the total sale price of all books in this list for a given discount
  double salePrice(double discount);

  // to return a list of all the books in this list of books
  // published before the given year
  ILoBook allBooksBefore(int year);

  // to construct a list of books that contains the same books as
  // this list of books, but sorted increasing by price
  ILoBook sortByPrice();

  ILoBook insert(Book b);

  // to construct a list of books that contains the same books as
  // this list of books, but sorted lexicographic by title
  ILoBook sortByTitle();

  ILoBook insertByTitle(Book b);
}

class MtLoBook implements ILoBook {

  MtLoBook() {
    // nothing to do!
  }

  public double totalPrice() {
    return 0;
  }

  public int count() {
    return 0;
  }

  @Override
  public double salePrice(double discount) {
    return 0;
  }

  public ILoBook allBooksBefore(int year) {
    return this;
    // return new MtLoBook();
  }

  public ILoBook sortByPrice() {
    return this;
    // return new MtLoBook();
  }

  public ILoBook insert(Book b) {
    return new ConsLoBook(b, this);
  }

  @Override
  public ILoBook sortByTitle() {
    return this;
  }

  @Override
  public ILoBook insertByTitle(Book b) {
    return new ConsLoBook(b, this);
  }
}

class ConsLoBook implements ILoBook {

  Book first;
  ILoBook rest;

  ConsLoBook(Book first, ILoBook rest) {
    this.first = first;
    this.rest = rest;
  }

  public double totalPrice() {
    /* Template:
     * FIELDS:
     * this.first -- Book
     * this.rest -- ILoBook
     * METHODS:
     * this.totalPrice() -- double
     * this.count() -- int
     * this.allBooksBefore(int) -- ILoBook
     * this.sortByPrice() -- ILoBook
     * this.sortByTitle() -- ILoBook
     * METHODS OF FIELDS:
     * this.first.getPrice() -- double ****
     * this.first.discount(double) -- double
     * this.first.discountedBook(double) -- Book
     * this.first.cheaperThan(Book) -- boolean
     * this.first.titleBefore(Book) -- boolean
     * this.rest.totalPrice() -- double  *****
     * this.rest.count() -- int
     * this.rest.allBooksBefore(int) -- ILoBook
     * this.rest.sortByPrice() -- ILoBook
     */
    return this.first.getPrice() + this.rest.totalPrice();
  }

  public int count() {
    return 1 + this.rest.count();
  }

  @Override
  public double salePrice(double discount) {
    return this.first.discount(discount / 100.0) + this.rest.salePrice(discount);
  }

  public ILoBook allBooksBefore(int year) {
    if (this.first.year < year) {
      return new ConsLoBook(
          this.first,
          this.rest.allBooksBefore(year));
    } else {
      return this.rest.allBooksBefore(year);
    }
  }

  public ILoBook sortByPrice() {
    /*
     * Assuming we have:
     * ILoBook insert(Book) -- on cons? on ilobook?
     * boolean isCheaper(Book) -- on Book
     */

    return this.rest.sortByPrice().insert(this.first);
  }

  // to insert the given book into this sorted list of books
  public ILoBook insert(Book b) {
    if (b.cheaperThan(this.first)) {
      return new ConsLoBook(b, this);
    } else {
      return new ConsLoBook(this.first, this.rest.insert(b));
    }
  }

  // to construct a list of books that contains the same books as
  // this list of books, but sorted lexicographic by title
  @Override
  public ILoBook sortByTitle() {
    return this.rest.sortByTitle().insertByTitle(this.first);
  }

  // to insert the given book into this sorted by title list of books
  @Override
  public ILoBook insertByTitle(Book b) {
    if (b.titleBefore(this.first)) {
      return new ConsLoBook(b, this);
    } else {
      return new ConsLoBook(this.first, this.rest.insertByTitle(b));
    }
  }
}


class ExamplesBooks {

  //Books
  Book htdp = new Book("HtDP", "MF", 60.0, 2001);
  Book lpp = new Book("LPP", "STX", 25.0, 1942);
  Book ll = new Book("LL", "FF", 10.0, 1986);

  // lists of Books
  ILoBook mtlist = new MtLoBook();
  ILoBook lista = new ConsLoBook(this.lpp, this.mtlist);
  ILoBook listb = new ConsLoBook(this.htdp, this.mtlist);
  ILoBook listc = new ConsLoBook(this.lpp,
      new ConsLoBook(this.ll, this.listb));
  ILoBook listd = new ConsLoBook(this.ll,
      new ConsLoBook(this.lpp,
          new ConsLoBook(this.htdp, this.mtlist)));
  ILoBook listdUnsorted =
      new ConsLoBook(this.lpp,
          new ConsLoBook(this.htdp,
              new ConsLoBook(this.ll, this.mtlist)));

  // test the count method of classes ILoBook type
  boolean testCountBookLists(Tester t) {
    return t.checkExpect(this.mtlist.count(), 0) &&
        t.checkExpect(this.lista.count(), 1) &&
        t.checkExpect(this.listc.count(), 3);
  }

  // test the sale price method of classes ILoBook type
  boolean testSalePriceBookLists(Tester t) {
    return
        // no discount -- full price
        t.checkInexact(this.mtlist.salePrice(0), 0.0, 0.001) &&
            t.checkInexact(this.lista.salePrice(0), 25.0, 0.001) &&
            t.checkInexact(this.listc.salePrice(0), 95.0, 0.001) &&
            t.checkInexact(this.listd.salePrice(0), 95.0, 0.001) &&
            // 50% off sale -- half price
            t.checkInexact(this.mtlist.salePrice(50), 0.0, 0.001) &&
            t.checkInexact(this.lista.salePrice(50), 12.5, 0.001) &&
            t.checkInexact(this.listc.salePrice(50), 47.5, 0.001) &&
            t.checkInexact(this.listd.salePrice(50), 47.5, 0.001);
  }

  // test the all books before method of classes ILoBook type
  boolean testAllBooksBeforeBookLists(Tester t) {
    return
        t.checkExpect(this.mtlist.allBooksBefore(2001), this.mtlist) &&
            t.checkExpect(this.lista.allBooksBefore(2001), this.lista) &&
            t.checkExpect(this.listb.allBooksBefore(2001), this.mtlist) &&
            t.checkExpect(this.listc.allBooksBefore(2001),
                new ConsLoBook(this.lpp, new ConsLoBook(this.ll, this.mtlist))) &&
            t.checkExpect(this.listd.allBooksBefore(2001),
                new ConsLoBook(this.ll, new ConsLoBook(this.lpp, this.mtlist)));
  }

  // test the method sort for the lists of books
  boolean testSort(Tester t) {
    return
        t.checkExpect(this.listc.sortByPrice(), this.listd) &&
            t.checkExpect(this.listdUnsorted.sortByPrice(), this.listd);
  }

  // test the method sortByTitle for the lists of books
  boolean testSortByTitle(Tester t) {
    return
        t.checkExpect(this.listc.sortByTitle(), new ConsLoBook(this.htdp,
            new ConsLoBook(this.ll, new ConsLoBook(this.lpp, new MtLoBook())))) &&
            t.checkExpect(this.lista.sortByTitle(), this.lista);
  }
}






