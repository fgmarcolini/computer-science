import tester.Tester;

// to represent a document
interface IDocument {

  // compute the information about this document with the next format:
  // Last name, First name. "Title".
  String format();

  // if this document's author if alphabetically before than the given document
  boolean isAlphabeticallyBeforeThan(IDocument document);

  boolean isAlphabeticallyBeforeThanHelper(String lastName);

  // if this document is the same (author and title) as the given arg
  boolean sameAs(IDocument document);

  boolean sameAsBook(Book book);

  boolean sameAsWikiArticle(WikiArticle wikiArticle);
}

// to represent an author of a book
class Author {

  String lastName;
  String firstName;

  Author(String lastName, String firstName) {
    this.lastName = lastName;
    this.firstName = firstName;
  }

  /*
   * TEMPLATE
   * +------------------------------------------+
   * FIELDS
   * ... this.lastName ... -- String
   * ... this.firstName ... -- String
   * +------------------------------------------+
   * METHODS
   * ... this.toString() ... -- String
   * ... this.getLastName() ... -- String
   */

  public String toString() {
    return this.lastName + ", " + this.firstName + ".";
  }

  public String getLastName() {
    return this.lastName;
  }
}

// to represent a book
class Book implements IDocument {

  Author author;
  String title;
  String publisher;

  Book(Author author, String title, String publisher) {
    this.author = author;
    this.title = title;
    this.publisher = publisher;
  }

  /*
   * TEMPLATE
   * +------------------------------------------+
   * FIELDS
   * ... this.author ... -- Author
   * ... this.title ... -- String
   * ... this.publisher ... -- String
   * +------------------------------------------+
   * METHODS
   * ... this.format() ... -- String
   * ... this.isAlphabeticallyBeforeThan(IDocument document) ... -- boolean
   * ... this.isAlphabeticallyBeforeThanHelper(String lastName) ... -- boolean
   * ... this.sameAs(IDocument document) ... -- boolean
   * ... this.sameAsBook(Book book) ... -- boolean
   * ... this.sameAsWikiArticle(WikiArticle wikiArticle) ... -- boolean
   * +------------------------------------------+
   * METHODS OF FIELDS
   * ... this.author.toString() ... -- String
   * ... this.author.getLastName() ... -- String
   * +------------------------------------------+
   */

  // compute the information about this Book with the next format:
  // Last name, First name. "Title".
  @Override
  public String format() {
    return this.author.toString() + " '" + this.title + "'.";
  }

  // if this Book's author if alphabetically before than the given document
  @Override
  public boolean isAlphabeticallyBeforeThan(IDocument document) {
    return !document.isAlphabeticallyBeforeThanHelper(this.author.getLastName());
  }

  @Override
  public boolean isAlphabeticallyBeforeThanHelper(String lastName) {
    return (this.author.getLastName().compareTo(lastName) < 0);
  }

  // if this Book is the same (author and title) as the given arg
  @Override
  public boolean sameAs(IDocument document) {
    return document.sameAsBook(this);
  }

  @Override
  public boolean sameAsBook(Book book) {
    return
        (this.author.getLastName().equals(book.author.getLastName())) &&
            (this.title.equals(book.title));
  }

  @Override
  public boolean sameAsWikiArticle(WikiArticle wikiArticle) {
    return
        (this.author.getLastName().equals(wikiArticle.author.getLastName())) &&
            (this.title.equals(wikiArticle.title));
  }
}

// to represent a wiki article
class WikiArticle implements IDocument {

  Author author;
  String title;
  String url;

  WikiArticle(Author author, String title, String url) {
    this.author = author;
    this.title = title;
    this.url = url;
  }

  /*
   * TEMPLATE
   * +------------------------------------------+
   * FIELDS
   * ... this.author ... -- Author
   * ... this.title ... -- String
   * ... this.url ... -- String
   * +------------------------------------------+
   * METHODS
   * ... this.format() ... -- String
   * ... this.isAlphabeticallyBeforeThan(IDocument document) ... -- boolean
   * ... this.isAlphabeticallyBeforeThanHelper(String lastName) ... -- boolean
   * ... this.sameAs(IDocument document) ... -- boolean
   * ... this.sameAsBook(Book book) ... -- boolean
   * ... this.sameAsWikiArticle(WikiArticle wikiArticle) ... -- boolean
   * +------------------------------------------+
   * METHODS OF FIELDS
   * ... this.author.toString() ... -- String
   * ... this.author.getLastName() ... -- String
   * +------------------------------------------+
   */

  // compute the information about this WikiArticle with the next format:
  // Last name, First name. "Title".
  @Override
  public String format() {
    return this.author.toString() + " '" + this.title + "'.";
  }

  // if this WikiArticle's author if alphabetically before than the given document
  @Override
  public boolean isAlphabeticallyBeforeThan(IDocument document) {
    return !document.isAlphabeticallyBeforeThanHelper(this.author.getLastName());
  }

  @Override
  public boolean isAlphabeticallyBeforeThanHelper(String lastName) {
    return (this.author.getLastName().compareTo(lastName) < 0);
  }

  // if this WikiArticle is the same (author and title) as the given arg
  @Override
  public boolean sameAs(IDocument document) {
    return document.sameAsWikiArticle(this);
  }

  @Override
  public boolean sameAsBook(Book book) {
    return
        (this.author.getLastName().equals(book.author.getLastName())) &&
            (this.title.equals(book.title));
  }

  @Override
  public boolean sameAsWikiArticle(WikiArticle wikiArticle) {
    return
        (this.author.getLastName().equals(wikiArticle.author.getLastName())) &&
            (this.title.equals(wikiArticle.title));
  }
}

// to represent a list of documents (a bibliography)
interface ILoDocument {

  // to compute a new document of this sorted by author's last name.
  ILoDocument sortByAuthor();

  // to compute a new list of documents (with no duplicates)
  // with the given documents sorted by alphabetically by author's last name
  ILoDocument insert(IDocument document);

  // if this list of documents contains the given document
  boolean contains(IDocument document);
}

// to represent an empty list of documents
class MtLoDocument implements ILoDocument {

  // to compute a new document of this MtLoDocuments sorted by author's last name.
  @Override
  public ILoDocument sortByAuthor() {
    return this;
  }

  // to compute a new list of documents with the given document
  // sorted by alphabetically by author's last name
  @Override
  public ILoDocument insert(IDocument document) {
    return new ConsLoDocument(document, new MtLoDocument());
  }

  // if this list of documents empty contains the given document
  @Override
  public boolean contains(IDocument document) {
    return false;
  }
}

// to represent a non-empty list of documents
class ConsLoDocument implements ILoDocument {

  IDocument first;
  ILoDocument rest;

  ConsLoDocument(IDocument first, ILoDocument rest) {
    this.first = first;
    this.rest = rest;
  }

  /*
   * TEMPLATE
   * +------------------------------------------+
   * FIELDS
   * ... this.first ... -- IDocument
   * ... this.rest ... -- ILoDocument
   * +------------------------------------------+
   * METHODS
   * ... this.sortByAuthor() ... -- ILoDocument
   * ... this.insert(IDocument document) ... -- ILoDocument
   * ... this.contains(IDocument document) ... -- boolean
   * +------------------------------------------+
   * METHODS OF FIELDS
   * ... this.first.format() ... -- String
   * ... this.first.isAlphabeticallyBeforeThan(IDocument document) ... -- boolean
   * ... this.first.sameAs(IDocument document) ... -- boolean
   * ... this.first.sameAsBook(Book book) ... -- boolean
   * ... this.first.sameAsWikiArticle(WikiArticle wikiArticle) ... -- boolean
   * +------------------------------------------+
   */

  // to compute a new document of this ConsLoDocument sorted by author's last name.
  @Override
  public ILoDocument sortByAuthor() {
    return this.rest.sortByAuthor().insert(this.first);
  }

  // to compute a new list of documents (with no duplicates)
  // with the given documents sorted by alphabetically by author's last name
  @Override
  public ILoDocument insert(IDocument document) {
    if (this.contains(document)) {
      return this;
    } else {
      return (document.isAlphabeticallyBeforeThan(first)) ?
          new ConsLoDocument(document, this) :
          new ConsLoDocument(first, rest.insert(document));
    }
  }

  // if this list of documents non-empty contains the given document
  @Override
  public boolean contains(IDocument document) {
    return this.first.sameAs(document) || this.rest.contains(document);
  }
}

class ExamplesBibliography {

  Author jkr1 = new Author("Rowling A", "JK");
  Author jkr2 = new Author("Rowling B", "JK");
  Author jkr3 = new Author("Rowling C", "JK");
  IDocument hp1 = new Book(this.jkr2, "Harry Potter and The Sorcerer's Stone", "Bloomsbury");
  IDocument hp2 = new Book(this.jkr1, "Harry Potter and The Chamber Of Secrets", "Bloomsbury");
  IDocument hp3 = new WikiArticle(this.jkr3, "Harry Potter Tips", "www.hptips.com");
  ILoDocument empty = new MtLoDocument();
  ILoDocument lst1 = new ConsLoDocument(this.hp1, this.empty);
  ILoDocument lst2 = new ConsLoDocument(this.hp1,
      new ConsLoDocument(this.hp2, new ConsLoDocument(this.hp3, this.empty)));
  ILoDocument unsortedLst = new ConsLoDocument(this.hp3,
      new ConsLoDocument(this.hp1, new ConsLoDocument(this.hp2, this.empty)));
  ILoDocument unsortedLst2 = new ConsLoDocument(this.hp1,
      new ConsLoDocument(this.hp2, this.empty));

  // to test the format method of classes IDocument
  boolean testIDocumentFormat(Tester t) {
    return
        t.checkExpect(this.hp1.format(), "Rowling B, JK. 'Harry Potter and The Sorcerer's Stone'.")
            &&
            t.checkExpect(this.hp3.format(), "Rowling C, JK. 'Harry Potter Tips'.");
  }

  // to test the isAlphabeticallyBeforeThan method of classes IDocument
  boolean testIDocumentIsAlhabeticallyBeforeThan(Tester t) {
    return
        t.checkExpect(this.hp1.isAlphabeticallyBeforeThan(this.hp1), true) &&
            t.checkExpect(this.hp2.isAlphabeticallyBeforeThan(this.hp1), true) &&
            t.checkExpect(this.hp3.isAlphabeticallyBeforeThan(this.hp1), false);
  }

  // to test the insert method of classes ILoDocument
  boolean testILoDocumentInsert(Tester t) {
    return
        t.checkExpect(this.empty.insert(this.hp1), new ConsLoDocument(this.hp1, this.empty)) &&
            t.checkExpect(this.lst1.insert(this.hp2),
                new ConsLoDocument(this.hp2, new ConsLoDocument(this.hp1, this.empty)));
  }

  // to test the contains method of classes ILoDocument
  boolean testILoDocumentContains(Tester t) {
    return
        t.checkExpect(this.empty.contains(this.hp2), false) &&
            t.checkExpect(this.lst1.contains(this.hp1), true) &&
            t.checkExpect(this.lst2.contains(this.hp3), true);
  }

  // to test the sortByAuthor method of classes ILoDocument
  boolean testILoDocumentSortByAuthor(Tester t) {
    return
        t.checkExpect(this.empty.sortByAuthor(), this.empty) &&
            t.checkExpect(this.lst1.sortByAuthor(), this.lst1) &&
            t.checkExpect(this.lst2.sortByAuthor(), new ConsLoDocument(this.hp2,
                new ConsLoDocument(this.hp1, new ConsLoDocument(this.hp3, empty)))) &&
            t.checkExpect(this.unsortedLst2.sortByAuthor(),
                new ConsLoDocument(this.hp2, new ConsLoDocument(this.hp1, this.empty))) &&
            t.checkExpect(this.unsortedLst.sortByAuthor(), new ConsLoDocument(this.hp2,
                new ConsLoDocument(this.hp1, new ConsLoDocument(this.hp3, empty)))) &&
            t.checkExpect(new ConsLoDocument(this.hp3, this.lst2).sortByAuthor(),
                new ConsLoDocument(this.hp2,
                    new ConsLoDocument(this.hp1, new ConsLoDocument(this.hp3, empty))));
  }
}