import tester.Tester;

// to represent a list of integers
interface ILoInt {

  // if the list contains:
  // - A number that is even
  // - A number that is positive and odd
  // - A number between 5 and 10, inclusive
  boolean checkCriteria();

  boolean containsEven();

  boolean containsPositiveOdd();

  boolean containsBetween5And10();

  // if the list contains:
  // - A number that is even AND
  // - A number that is positive and odd AND
  // - A number between 5 and 10, inclusive
  // The numbers have to be different between each other
  boolean checkCriteria2();

  ILoInt removeEven();

  ILoInt removePositiveOdd();


  // if the list contains:
  // - A number that is even AND
  // - A number that is positive and odd AND
  // - A number between 5 and 10, inclusive
  // - Non extraneous numbers, means greater than 10
  // The numbers have to be different between each other
  boolean checkCriteria3();

  boolean nonExtraneousNumber();

}

// to represent a list empty of integers
class MtLoInt implements ILoInt {

  // means it isn't any integer that satisfies all
  @Override
  public boolean checkCriteria() {
    return false;
  }

  @Override
  public boolean containsEven() {
    return false;
  }

  @Override
  public boolean containsPositiveOdd() {
    return false;
  }

  @Override
  public boolean containsBetween5And10() {
    return false;
  }

  @Override
  public boolean checkCriteria2() {
    return false;
  }

  @Override
  public ILoInt removeEven() {
    return new MtLoInt();
  }

  @Override
  public ILoInt removePositiveOdd() {
    return new MtLoInt();
  }

  @Override
  public boolean checkCriteria3() {
    return false;
  }

  @Override
  public boolean nonExtraneousNumber() {
    return true;
  }
}

// to represent a list non-empty of integers
class ConsLoInt implements ILoInt {

  int first;
  ILoInt rest;

  ConsLoInt(int first, ILoInt rest) {
    this.first = first;
    this.rest = rest;
  }

  /*
   * TEMPLATE
   * +------------------------------------------+
   * FIELDS
   * ... this.first ... -- int
   * ... this.rest ... -- ILoInt
   * +------------------------------------------+
   * METHODS
   * ... this.checkCriteria() ... -- boolean
   * ... this.containsEven() ... -- boolean
   * ... this.containsPositiveOdd() ... -- boolean
   * ... this.containsBetween5And10() ... -- boolean
   */


  // if the list contains:
  // - A number that is even
  // - A number that is positive and odd
  // - A number between 5 and 10, inclusive
  @Override
  public boolean checkCriteria() {
    return
        this.containsEven() &&
            this.containsPositiveOdd() &&
            this.containsBetween5And10();
  }

  @Override
  public boolean containsEven() {
    return this.first % 2 == 0 || this.rest.containsEven();
  }

  @Override
  public boolean containsPositiveOdd() {
    return (this.first % 2 != 0 && this.first > 0) || this.rest.containsPositiveOdd();
  }

  @Override
  public boolean containsBetween5And10() {
    return (this.first >= 5 && this.first <= 10) || this.rest.containsBetween5And10();
  }

  // if the list contains:
  // - A number that is even AND
  // - A number that is positive and odd AND
  // - A number between 5 and 10, inclusive
  // The numbers have to be different between each other
  @Override
  public boolean checkCriteria2() {
    return (this.removeEven().removePositiveOdd()).containsBetween5And10();
  }

  @Override
  public ILoInt removeEven() {
    return (this.first % 2 == 0) ? this.rest : new ConsLoInt(this.first, this.rest.removeEven());
  }

  @Override
  public ILoInt removePositiveOdd() {
    return (this.first % 2 != 0 && this.first > 0) ? this.rest
        : new ConsLoInt(this.first, this.rest.removePositiveOdd());
  }

  // if the list contains:
  // - A number that is even AND
  // - A number that is positive and odd AND
  // - A number between 5 and 10, inclusive
  // - Non extraneous numbers, means greater than 10
  // The numbers have to be different between each other
  @Override
  public boolean checkCriteria3() {
    return (this.removeEven().removePositiveOdd()).containsBetween5And10()
        && this.nonExtraneousNumber();
  }

  @Override
  public boolean nonExtraneousNumber() {
    return !(this.first > 10) && this.rest.nonExtraneousNumber();
  }

}

class ExamplesILoInt {

  ILoInt empty = new MtLoInt();
  ILoInt lst1 = new ConsLoInt(6, new ConsLoInt(5, this.empty));
  ILoInt lst2 = new ConsLoInt(4, new ConsLoInt(3, this.empty));

  // to test checkCriteria method of classes ILoInt
  boolean testILoIntCheckCriteria(Tester t) {
    return
        t.checkExpect(this.empty.checkCriteria(), false) &&
            t.checkExpect(this.lst1.checkCriteria(), true) &&
            t.checkExpect(this.lst2.checkCriteria(), false);
  }

  // to test checkCriteria2 method of classes ILoInt
  boolean testILoIntCheckCriteria2(Tester t) {
    return
        t.checkExpect(this.empty.checkCriteria2(), false) &&
            t.checkExpect(this.lst1.checkCriteria2(), false) &&
            t.checkExpect((new ConsLoInt(6, this.lst1)).checkCriteria2(),
                true);
  }

  // to test checkCriteria3 method of classes ILoInt
  boolean testILoIntCheckCriteria3(Tester t) {
    return
        t.checkExpect(this.empty.checkCriteria3(), false) &&
            t.checkExpect(this.lst1.checkCriteria3(), false) &&
            t.checkExpect((new ConsLoInt(6, this.lst1)).checkCriteria3(),
                true) &&
            t.checkExpect(new ConsLoInt(6, new ConsLoInt(42, this.lst1)).checkCriteria3(), false);
  }
}

